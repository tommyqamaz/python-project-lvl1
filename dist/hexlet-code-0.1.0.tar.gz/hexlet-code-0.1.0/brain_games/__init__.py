"""
High level support for doing this and that.

Second line.
"""
