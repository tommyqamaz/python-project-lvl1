#!/usr/bin/env python

from ..cli import get_user_name


def main():
    """Main part."""
    print("Welcome to the Brain Games!")
    get_user_name()


if __name__ == "__main__":
    main()
